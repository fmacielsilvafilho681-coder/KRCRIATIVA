function Cart({ isOpen, onClose, items, onRemove, onUpdateQuantity, onClear }) {
  const [step, setStep] = React.useState('cart'); // 'cart' | 'checkout' | 'success'
  const [formData, setFormData] = React.useState({ name: '', address: '' });
  const [loading, setLoading] = React.useState(false);
  const [lastOrder, setLastOrder] = React.useState(null);
  const [storeConfig, setStoreConfig] = React.useState(null);

  // Load store config when opening cart
  React.useEffect(() => {
    if (isOpen) {
        loadStoreConfig();
    }
    if (isOpen && step === 'success') {
       setStep('cart');
       setLastOrder(null);
    }
  }, [isOpen]);

  const loadStoreConfig = async () => {
    const config = await getStoreConfig();
    if (config) {
        setStoreConfig(config);
    }
  };

  if (!isOpen) return null;

  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const formatPrice = (price) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);

  const handleCheckout = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const orderItems = items.map(i => ({ 
        id: i.id, 
        name: i.name, 
        price: i.price, 
        quantity: i.quantity 
      }));

      const orderData = {
        customer_name: formData.name,
        customer_phone: 'Via WhatsApp',
        address: formData.address,
        items: orderItems,
        total: total,
        payment_method: 'A Combinar'
      };

      const newOrder = await createOrder(orderData);
      
      const savedOrder = {
        ...orderData,
        id: newOrder.objectId
      };
      
      setLastOrder(savedOrder);
      onClear();
      setStep('success');

      // Auto Redirect to WhatsApp
      setTimeout(() => openWhatsApp(savedOrder), 1000);

    } catch (error) {
      console.error(error);
      alert('Erro ao finalizar pedido. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const openWhatsApp = (order = null) => {
    const targetOrder = order || lastOrder;
    if (!targetOrder) return;

    const adminPhone = storeConfig?.whatsapp_number || "5511999999999"; 
    
    // Format items list
    const itemsList = targetOrder.items.map(i => `- ${i.name} (${i.quantity} un)`).join('\n');
    const orderId = targetOrder.id ? `#${targetOrder.id.slice(-4).toUpperCase()}` : 'Novo';

    let message = `Olá! Quero finalizar meu pedido na KR Criativa.

*Pedido:* ${orderId}
*Cliente:* ${targetOrder.customer_name}
*Endereço:* ${targetOrder.address}

*Itens do Pedido:*
${itemsList}

*Total:* ${formatPrice(targetOrder.total)}

Aguardo as instruções para pagamento!`;

    const url = `https://wa.me/${adminPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[150] flex justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm" onClick={onClose}></div>

      {/* Cart Drawer */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl cart-slide-in flex flex-col">
        
        {/* Header */}
        <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-white z-10">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <div className="icon-shopping-cart text-[#802EF2]"></div>
            Seu Carrinho
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors">
            <div className="icon-x text-xl"></div>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {step === 'cart' && (
            <>
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-400 space-y-4">
                  <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center">
                    <div className="icon-shopping-bag text-3xl opacity-30"></div>
                  </div>
                  <p>Seu carrinho está vazio.</p>
                  <button onClick={onClose} className="text-[#802EF2] font-semibold hover:underline">
                    Continuar comprando
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map(item => (
                    <div key={item.id} className="flex gap-4 p-3 rounded-xl bg-gray-50 border border-gray-100">
                      <div className="w-20 h-20 bg-white rounded-lg p-2 flex-shrink-0">
                         <img src={item.imageUrl} alt={item.name} className="w-full h-full object-contain mix-blend-multiply" />
                      </div>
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                            <h4 className="font-semibold text-gray-900 line-clamp-1">{item.name}</h4>
                            <p className="text-sm text-[#802EF2] font-bold">{formatPrice(item.price)}</p>
                        </div>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3 bg-white rounded-lg px-2 py-1 border border-gray-200">
                                <button onClick={() => onUpdateQuantity(item.id, -1)} className="text-gray-500 hover:text-[#802EF2] disabled:opacity-30" disabled={item.quantity <= 1}>
                                    <div className="icon-minus text-xs"></div>
                                </button>
                                <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                                <button onClick={() => onUpdateQuantity(item.id, 1)} className="text-gray-500 hover:text-[#802EF2]">
                                    <div className="icon-plus text-xs"></div>
                                </button>
                            </div>
                            <button onClick={() => onRemove(item.id)} className="text-red-400 hover:text-red-600 p-1">
                                <div className="icon-trash-2 text-sm"></div>
                            </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {step === 'checkout' && (
            <div className="space-y-6">
                
                <form id="checkout-form" onSubmit={handleCheckout} className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-xl space-y-4">
                        <h3 className="font-bold text-gray-900 flex items-center gap-2">
                            <div className="icon-user text-[#802EF2]"></div>
                            Seus Dados
                        </h3>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Nome Completo</label>
                            <input 
                                required
                                type="text" 
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#802EF2] focus:ring-4 focus:ring-[#802EF2]/10 outline-none transition-all"
                                placeholder="Como podemos te chamar?"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Endereço de Entrega</label>
                            <textarea 
                                required
                                rows="2"
                                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#802EF2] focus:ring-4 focus:ring-[#802EF2]/10 outline-none transition-all resize-none"
                                placeholder="Rua, Número, Bairro, Cidade..."
                                value={formData.address}
                                onChange={e => setFormData({...formData, address: e.target.value})}
                            ></textarea>
                        </div>
                    </div>
                    
                    <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 flex items-start gap-3">
                         <div className="icon-message-circle text-purple-600 mt-1"></div>
                         <p className="text-sm text-purple-800">
                             Ao finalizar, você será redirecionado para o <strong>WhatsApp</strong> para combinar o pagamento diretamente com a loja.
                         </p>
                    </div>
                </form>

                <div className="bg-gray-50 p-4 rounded-xl space-y-2">
                    <h5 className="font-bold text-gray-900 text-sm">Resumo</h5>
                    <div className="border-t border-gray-200 pt-2 flex justify-between font-bold text-gray-900 text-lg">
                        <span>Total</span>
                        <span>{formatPrice(total)}</span>
                    </div>
                </div>
            </div>
          )}

          {step === 'success' && (
            <div className="h-full flex flex-col items-center text-center animate-[fadeIn_0.5s] p-2 space-y-6">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                    <div className="icon-check text-4xl text-green-600"></div>
                </div>
                
                <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-1">Pedido Enviado!</h3>
                    <p className="text-gray-500 text-sm">
                       Seu pedido foi registrado. Se o WhatsApp não abriu, clique no botão abaixo.
                    </p>
                </div>

                <div className="w-full space-y-3">
                     <button 
                        onClick={() => openWhatsApp()}
                        className="w-full py-4 rounded-xl bg-[#25D366] text-white font-bold shadow-lg shadow-green-500/20 hover:bg-[#128C7E] hover:-translate-y-1 transition-all flex items-center justify-center gap-3"
                    >
                        <div className="icon-message-circle text-2xl fill-current"></div>
                        <span>Abrir WhatsApp</span>
                    </button>
                </div>

                <button 
                    onClick={onClose}
                    className="text-gray-400 hover:text-gray-600 text-sm font-medium transition-colors"
                >
                    Voltar para a Loja
                </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {items.length > 0 && step !== 'success' && (
            <div className="p-5 border-t border-gray-100 bg-gray-50">
                {step === 'cart' ? (
                    <div className="space-y-4">
                        <div className="flex justify-between items-end">
                            <span className="text-gray-500 text-sm">Subtotal</span>
                            <span className="text-2xl font-bold text-gray-900">{formatPrice(total)}</span>
                        </div>
                        <button 
                            onClick={() => setStep('checkout')}
                            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#802EF2] to-[#F24BE7] text-white font-bold shadow-lg shadow-[#802EF2]/20 hover:shadow-[#F24BE7]/40 hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
                        >
                            Continuar
                            <div className="icon-arrow-right"></div>
                        </button>
                    </div>
                ) : (
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setStep('cart')}
                            className="px-6 py-4 rounded-xl border border-gray-200 text-gray-600 font-bold hover:bg-white transition-colors"
                        >
                            Voltar
                        </button>
                        <button 
                            form="checkout-form"
                            type="submit"
                            disabled={loading}
                            className="flex-1 py-4 rounded-xl bg-[#25D366] text-white font-bold shadow-lg shadow-green-500/20 hover:bg-[#128C7E] hover:-translate-y-1 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
                        >
                            {loading ? (
                                <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>
                            ) : (
                                <>
                                    <div className="icon-message-circle"></div>
                                    Enviar Pedido
                                </>
                            )}
                        </button>
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
}