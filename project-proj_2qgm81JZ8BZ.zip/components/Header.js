function Header({ isAdmin = false, cartCount = 0, onOpenCart }) {
  return (
    <header className="py-3 md:py-6 px-4 md:px-8 flex justify-between items-center sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-[#802EF2]/10 transition-all duration-300">
      <div className="flex items-center gap-3" data-name="logo-container">
        <img 
            src="https://app.trickle.so/storage/public/images/usr_1a01139ad8000001/0e497727-f245-46af-8b81-648d8c1212a8.png?w=3868&h=3160" 
            alt="KR Criativa Logo" 
            className="h-8 md:h-12 w-auto object-contain"
        />
      </div>
      <nav className="flex items-center gap-4 md:gap-6">
        {!isAdmin ? (
          <>
            <a href="index.html" className="hidden md:block text-gray-600 hover:text-[#802EF2] font-medium transition-colors text-sm relative group">
              Loja
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#802EF2] transition-all group-hover:w-full"></span>
            </a>
            
            {/* Cart Button */}
            <button 
                onClick={onOpenCart}
                className="relative p-2 rounded-full hover:bg-gray-100 transition-colors group"
            >
                <div className="icon-shopping-cart text-xl text-gray-600 group-hover:text-[#802EF2] transition-colors"></div>
                {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-[#F24BE7] text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-sm animate-[bounce_0.5s]">
                        {cartCount}
                    </span>
                )}
            </button>

            <a href="admin.html" className="text-gray-500 hover:text-[#802EF2] transition-colors text-xs md:text-sm font-medium">
              Admin
            </a>
          </>
        ) : (
          <>
             <a href="index.html" className="text-gray-500 hover:text-[#802EF2] transition-colors text-xs md:text-sm font-medium">
                Voltar
             </a>
             <div className="px-3 py-1 md:px-4 md:py-1.5 rounded-full bg-[#802EF2]/10 text-[#802EF2] text-[10px] md:text-xs font-bold border border-[#802EF2]/20 tracking-wide">
                PAINEL
             </div>
          </>
        )}
      </nav>
    </header>
  );
}