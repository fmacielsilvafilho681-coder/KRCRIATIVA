function ProductCard({ product, onEdit, onDelete, isAdmin, onClick, onAddToCart }) {
  const formatPrice = (price) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);
  };

  const handleClick = (e) => {
    // If clicking on buttons, don't trigger main click
    if (e.target.closest('button')) return;
    if (onClick) onClick(product);
  };

  // Determine main image: use first from 'images' array, fallback to 'imageUrl', fallback to placeholder
  let mainImage = 'https://via.placeholder.com/400x300?text=Sem+Imagem';
  try {
      if (product.images) {
          const imgs = typeof product.images === 'string' ? JSON.parse(product.images) : product.images;
          if (Array.isArray(imgs) && imgs.length > 0) {
              mainImage = imgs[0];
          } else if (product.imageUrl) {
              mainImage = product.imageUrl;
          }
      } else if (product.imageUrl) {
          mainImage = product.imageUrl;
      }
  } catch (e) {
      if (product.imageUrl) mainImage = product.imageUrl;
  }

  return (
    <div 
        className={`group bg-white rounded-xl md:rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-[#802EF2]/10 transition-all duration-300 flex flex-col h-full border border-gray-100/50 ${!isAdmin ? 'cursor-pointer' : ''}`} 
        data-name="product-card"
        onClick={!isAdmin ? handleClick : undefined}
    >
      <div className="relative aspect-square md:aspect-[4/3] overflow-hidden bg-gray-50/50 p-2 md:p-6 flex items-center justify-center group-hover:bg-white transition-colors">
        <img 
          src={mainImage} 
          alt={product.name}
          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 mix-blend-multiply"
        />
        <div className="absolute top-2 left-2 md:top-4 md:left-4">
             <span className="px-1.5 py-0.5 md:px-3 md:py-1 rounded-full bg-white/90 backdrop-blur text-gray-600 text-[9px] md:text-xs font-semibold shadow-sm border border-gray-100 truncate max-w-[80px] md:max-w-none">
                {product.category}
             </span>
        </div>
        
        {!isAdmin && (
            <div className="hidden md:flex absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 items-center justify-center">
                <div className="bg-white/90 backdrop-blur px-4 py-2 rounded-full text-xs font-bold text-gray-800 shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-transform">
                    Ver Detalhes
                </div>
            </div>
        )}
      </div>
      
      <div className="p-3 md:p-6 flex-1 flex flex-col">
        <h3 className="text-sm md:text-lg font-bold text-gray-900 mb-1 md:mb-2 group-hover:text-[#802EF2] transition-colors leading-tight line-clamp-2">
          {product.name}
        </h3>
        <p className="hidden md:block text-gray-500 text-xs md:text-sm mb-3 md:mb-6 line-clamp-2 flex-1 leading-relaxed font-light">
          {product.description}
        </p>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between mt-auto pt-2 md:pt-4 border-t border-gray-50 gap-2 md:gap-0">
          <span className="text-sm md:text-xl font-bold bg-gradient-to-r from-[#802EF2] to-[#F24BE7] bg-clip-text text-transparent">
            {formatPrice(product.price)}
          </span>
          
          {isAdmin ? (
             <div className="flex gap-2">
                <button 
                  onClick={() => onEdit(product)}
                  className="p-2 md:p-2.5 rounded-xl bg-gray-50 text-gray-500 hover:bg-[#802EF2] hover:text-white transition-all duration-300"
                  title="Editar"
                >
                  <div className="icon-pencil text-base md:text-lg"></div>
                </button>
                <button 
                  onClick={() => onDelete(product.id)}
                  className="p-2 md:p-2.5 rounded-xl bg-gray-50 text-gray-500 hover:bg-red-500 hover:text-white transition-all duration-300"
                  title="Excluir"
                >
                  <div className="icon-trash text-base md:text-lg"></div>
                </button>
             </div>
          ) : (
            <button 
                onClick={(e) => {
                    e.stopPropagation();
                    onAddToCart && onAddToCart(product);
                }}
                className="w-full md:w-auto py-1.5 md:p-3 rounded-lg md:rounded-2xl bg-gray-100 text-[#802EF2] hover:bg-[#802EF2] hover:text-white transition-all duration-300 relative z-10 group/btn flex items-center justify-center"
                title="Adicionar ao Carrinho"
            >
               <div className="icon-shopping-cart text-sm md:text-lg md:hidden"></div>
               <span className="text-xs font-bold md:hidden ml-1">Add</span>
               <div className="icon-shopping-cart text-base md:text-lg hidden md:block"></div>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
