function ProductModal({ product, onClose, onAddToCart }) {
  if (!product) return null;
  const [storeConfig, setStoreConfig] = React.useState(null);
  const [selectedImageIndex, setSelectedImageIndex] = React.useState(0);
  const [images, setImages] = React.useState([]);

  React.useEffect(() => {
    loadStoreConfig();
    
    // Parse images
    let imgs = [];
    try {
        if (product.images) {
            imgs = typeof product.images === 'string' ? JSON.parse(product.images) : product.images;
        }
    } catch (e) {}
    
    // Fallback logic
    if (!Array.isArray(imgs) || imgs.length === 0) {
        if (product.imageUrl) imgs = [product.imageUrl];
        else imgs = ['https://via.placeholder.com/400x300?text=Sem+Imagem'];
    }
    
    setImages(imgs);
  }, [product]);

  const loadStoreConfig = async () => {
    try {
        const config = await getStoreConfig();
        if (config) setStoreConfig(config);
    } catch(e) { console.error(e); }
  };

  const handleShare = async () => {
    const shareData = {
      title: product.name,
      text: `Confira este produto incrível na KR Criativa: ${product.name} por ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)}`,
      url: window.location.href
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text} - ${shareData.url}`);
        alert('Link copiado!');
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  const handleBuy = () => {
    const productToAdd = {
        ...product,
        imageUrl: images[0] 
    };
    onAddToCart(productToAdd);
    onClose();
  };

  const handleDirectWhatsApp = () => {
    const adminPhone = storeConfig?.whatsapp_number || "5511999999999"; 
    
    let message = `Olá! Tenho interesse no produto:
    
*${product.name}*
Preço: ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)}

Gostaria de saber mais informações e como comprar.`;

    const url = `https://wa.me/${adminPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-4 bg-gray-900/60 backdrop-blur-sm" onClick={onClose}>
      <div 
        className="bg-white w-full h-[95vh] md:h-auto md:max-w-5xl md:rounded-3xl rounded-t-3xl shadow-2xl overflow-hidden modal-content flex flex-col md:flex-row relative"
        onClick={e => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 backdrop-blur text-gray-500 hover:text-red-500 hover:bg-white transition-all shadow-sm md:block hidden"
        >
          <div className="icon-x text-xl"></div>
        </button>

        {/* Mobile Drag/Close Indicator */}
        <div className="md:hidden absolute top-0 left-0 right-0 h-8 z-20 flex items-center justify-center" onClick={onClose}>
             <div className="w-12 h-1.5 rounded-full bg-gray-300"></div>
        </div>

        {/* Image Section */}
        <div className="w-full md:w-1/2 bg-gray-50 relative group flex flex-col pt-8 md:pt-0">
            {/* Desktop Background Effect */}
            <div className="hidden md:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-tr from-[#802EF2]/5 to-[#F24BE7]/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
            
            {/* Mobile Horizontal Scroll Gallery */}
            <div className="md:hidden w-full h-[35vh] flex overflow-x-auto snap-x snap-mandatory no-scrollbar">
                {images.map((img, idx) => (
                    <div key={idx} className="w-full flex-shrink-0 snap-center flex items-center justify-center p-4 relative">
                        <img 
                            src={img} 
                            alt={`${product.name} ${idx + 1}`}
                            className="w-full h-full object-contain mix-blend-multiply drop-shadow-sm"
                        />
                        <div className="absolute bottom-2 right-4 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
                            {idx + 1} / {images.length}
                        </div>
                    </div>
                ))}
            </div>

            {/* Desktop Main Image */}
            <div className="hidden md:flex flex-1 items-center justify-center p-12 relative overflow-hidden">
                <img 
                    src={images[selectedImageIndex]} 
                    alt={product.name}
                    className="w-full h-full max-h-[400px] object-contain mix-blend-multiply relative z-10 drop-shadow-lg transition-all duration-300"
                />
            </div>

            {/* Desktop Thumbnails */}
            {images.length > 1 && (
                <div className="hidden md:flex p-4 gap-2 overflow-x-auto no-scrollbar justify-center z-10 bg-white/50 backdrop-blur-sm border-t border-gray-100/50">
                    {images.map((img, idx) => (
                        <button 
                            key={idx}
                            onClick={() => setSelectedImageIndex(idx)}
                            className={`w-16 h-16 rounded-lg border-2 overflow-hidden flex-shrink-0 transition-all ${selectedImageIndex === idx ? 'border-[#802EF2] shadow-md scale-105' : 'border-transparent opacity-60 hover:opacity-100'}`}
                        >
                            <img src={img} className="w-full h-full object-cover" />
                        </button>
                    ))}
                </div>
            )}
        </div>

        {/* Content Section */}
        <div className="w-full md:w-1/2 p-5 md:p-10 flex flex-col overflow-y-auto h-full max-h-[calc(60vh-60px)] md:max-h-[85vh]">
            <div className="mb-auto">
                <div className="flex items-center justify-between gap-2 mb-2 md:mb-4">
                    <span className="px-3 py-1 rounded-full bg-[#802EF2]/10 text-[#802EF2] text-xs font-bold uppercase tracking-wider">
                        {product.category}
                    </span>
                    <button onClick={onClose} className="md:hidden p-1 text-gray-400">
                        <div className="icon-x text-lg"></div>
                    </button>
                </div>

                <h2 className="text-xl md:text-3xl font-bold text-gray-900 mb-1 md:mb-4 leading-tight">
                    {product.name}
                </h2>
                
                <div className="flex items-baseline gap-2 mb-4 md:mb-8">
                    <span className="text-2xl md:text-4xl font-bold text-[#802EF2]">
                        {formatPrice(product.price)}
                    </span>
                    <span className="text-xs md:text-sm text-gray-400">à vista</span>
                </div>

                <div className="prose prose-sm md:prose-base text-gray-500 mb-20 md:mb-8 leading-relaxed">
                    <h4 className="text-gray-900 font-semibold mb-2 text-xs md:text-sm uppercase tracking-wide">Sobre o produto</h4>
                    <p>{product.description}</p>
                </div>
            </div>

            <div className="flex flex-col gap-3 mt-auto md:mt-4 pt-4 md:pt-6 border-t border-gray-100 bg-white fixed md:static bottom-0 left-0 right-0 p-4 md:p-0 z-20 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] md:shadow-none">
                <button 
                    onClick={handleDirectWhatsApp}
                    className="w-full py-3 md:py-4 rounded-xl bg-[#25D366] text-white font-bold shadow-xl shadow-green-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                    <div className="icon-message-circle text-lg md:text-xl fill-current"></div>
                    Quero este produto
                </button>
                
                <div className="grid grid-cols-2 gap-3">
                    <button 
                        onClick={handleBuy}
                        className="py-3 rounded-xl border border-gray-200 text-gray-600 font-bold hover:bg-gray-50 active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                        <div className="icon-shopping-cart text-lg"></div>
                        <span className="md:inline">Add Carrinho</span>
                    </button>
                    <button 
                        onClick={handleShare}
                        className="py-3 rounded-xl border border-gray-200 text-gray-600 font-bold hover:bg-gray-50 active:scale-95 transition-all flex items-center justify-center gap-2 group"
                    >
                        <div className="icon-share-2 text-lg group-hover:text-[#802EF2] transition-colors"></div>
                        <span className="md:inline">Compartilhar</span>
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
}