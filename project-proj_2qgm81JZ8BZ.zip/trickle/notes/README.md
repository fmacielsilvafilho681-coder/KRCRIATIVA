# Stationery Store Mini-Site

A minimalist and elegant stationery store website with separate Client and Admin views.

## Features
- **Client View**: Browse products, filter by category, search.
- **Cart & Checkout**: 
    - **Simplified Manual Flow**: 
        - Users add items to cart or buy directly.
        - Checkout redirects to **WhatsApp** with the order summary.
        - Order is saved in the database as "Não pago" for Admin records.
    - **Payment**: Negotiated directly via WhatsApp (Manual).
- **Admin View**: 
    - **Order Management**: 
        - Track orders (Status: Não pago, Pago, Entregue, Cancelado).
        - **Delete Orders**: Admin can remove test/old orders.
    - **Product Management**: CRUD operations for inventory.
    - **Configuration**: Set **WhatsApp Number** for receiving orders.

## Updates (2026-03-14)
- **Welcome Screen**: Added a gradient greeting screen on startup.
- **Image Upload**: Replaced URL input with direct file upload (Base64 storage).
- **Multiple Images**: Products now support up to 10 images with a gallery view.
- **Simplified Status**: Order statuses reduced to 4 key states.

## Structure
- `index.html`: Client facing store.
- `admin.html`: Admin dashboard.
- `app.js`: Client logic.
- `admin-app.js`: Admin logic (Products, Orders, Config).
- `components/Cart.js`: Checkout logic (WhatsApp Redirect).
- `utils/db.js`: Database abstraction layer.

## Maintenance
- Whenever the project logic or structure changes, please update this README to reflect the current state.