# Design System Rules

When building the Stationery Store interface:

- **Primary Background**: #FFFFFF (White)
- **Primary Text**: #1F2937 (Gray-900) for headings, #4B5563 (Gray-600) for body.
- **Brand Gradient**: `linear-gradient(135deg, #802EF2, #F24BE7)`
- **Brand Primary**: #802EF2 (Deep Purple)
- **Brand Secondary**: #F24BE7 (Magenta/Pink)
- **Style**: Minimalist, elegant, spacious, modern.

## UI Components
- **Buttons**: 
  - Primary: Brand Gradient background, White text, rounded-xl.
  - Hover: Opacity 90% or shadow increase.
- **Cards**: White background, soft shadow.
- **Typography**: Inter font. Clean, readable.
- **Icons**: Lucide icons.
- **Accents**: Use gradient for prices, active states, and key highlights.