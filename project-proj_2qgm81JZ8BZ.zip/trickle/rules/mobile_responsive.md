When designing for mobile (max-width: 768px)
- Reduce section padding (e.g., py-28 -> py-12)
- Reduce margins between elements (e.g., mb-32 -> mb-12)
- Compact card layouts (reduce internal padding)
- Smaller font sizes for headings to prevent wrapping/overflow
- Height of interactive elements like buttons and inputs should be proportional but not excessively large
- Avoid "empty" space; aim for a dense but organized information density
- Grid layouts should typically be 1 column on mobile with reduced gaps (gap-4)