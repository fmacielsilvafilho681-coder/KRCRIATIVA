// Database Utility Functions using Trickle DB API

const DB_TABLE_PRODUCT = 'product';
const DB_TABLE_ORDER = 'order';
const DB_TABLE_CONFIG = 'store_config';

async function fetchProducts() {
  try {
    const result = await trickleListObjects(DB_TABLE_PRODUCT, 100, true);
    if (!result || !result.items) return [];
    
    return result.items.map(item => ({
      id: item.objectId,
      ...item.objectData
    }));
  } catch (error) {
    console.error("Error fetching products:", error);
    return [];
  }
}

async function createProduct(data) {
  try {
    const price = parseFloat(data.price);
    const validPrice = isNaN(price) ? 0 : price;

    const productData = {
      name: String(data.name || ''),
      description: String(data.description || ''),
      price: validPrice,
      category: String(data.category || ''),
      imageUrl: String(data.imageUrl || ''), // Kept for compatibility
      images: JSON.stringify(data.images || []) // Store array of base64 strings
    };

    return await trickleCreateObject(DB_TABLE_PRODUCT, productData);
  } catch (error) {
    console.error("Error creating product:", error);
    throw error;
  }
}

async function updateProduct(id, data) {
  try {
    const price = parseFloat(data.price);
    const validPrice = isNaN(price) ? 0 : price;

    const productData = {
      name: String(data.name || ''),
      description: String(data.description || ''),
      price: validPrice,
      category: String(data.category || ''),
      imageUrl: String(data.imageUrl || ''),
      images: JSON.stringify(data.images || [])
    };

    return await trickleUpdateObject(DB_TABLE_PRODUCT, id, productData);
  } catch (error) {
    console.error("Error updating product:", error);
    throw error;
  }
}

async function deleteProduct(id) {
  try {
    return await trickleDeleteObject(DB_TABLE_PRODUCT, id);
  } catch (error) {
    console.error("Error deleting product:", error);
    throw error;
  }
}

async function createOrder(orderData) {
  try {
    // Initial history entry
    const initialHistory = [{
        date: new Date().toISOString(),
        action: 'Pedido criado',
        details: `Pedido iniciado via Site (WhatsApp)`
    }];

    // Ensure data matches schema
    const payload = {
        customer_name: String(orderData.customer_name || ''),
        customer_phone: String(orderData.customer_phone || ''),
        address: String(orderData.address || ''),
        items: JSON.stringify(orderData.items || []), // Store items as JSON string
        total: parseFloat(orderData.total || 0),
        status: 'Não pago', // Updated default status
        created_at: new Date().toISOString(),
        payment_method: String(orderData.payment_method || 'A Combinar'),
        history: JSON.stringify(initialHistory),
        tracking_code: ''
    };
    
    return await trickleCreateObject(DB_TABLE_ORDER, payload);
  } catch (error) {
    console.error("Error creating order:", error);
    throw error;
  }
}

async function fetchOrders() {
  try {
    // Fetch latest 100 orders
    const result = await trickleListObjects(DB_TABLE_ORDER, 100, true);
    if (!result || !result.items) return [];
    
    return result.items.map(item => ({
      id: item.objectId,
      ...item.objectData
    }));
  } catch (error) {
    console.error("Error fetching orders:", error);
    return [];
  }
}

async function updateOrder(id, updates, historyEntry = null) {
  try {
    // 1. Get current order to handle history
    const currentOrder = await trickleGetObject(DB_TABLE_ORDER, id);
    let history = [];
    try {
        if (currentOrder && currentOrder.objectData.history) {
            history = JSON.parse(currentOrder.objectData.history);
        }
    } catch (e) { console.warn("Could not parse history", e); }

    // 2. Append new history entry if provided
    if (historyEntry) {
        history.push({
            date: new Date().toISOString(),
            ...historyEntry
        });
    }

    // 3. Prepare payload
    const payload = {
        ...updates,
        history: JSON.stringify(history)
    };

    return await trickleUpdateObject(DB_TABLE_ORDER, id, payload);
  } catch (error) {
    console.error("Error updating order:", error);
    throw error;
  }
}

async function deleteOrder(id) {
  try {
    return await trickleDeleteObject(DB_TABLE_ORDER, id);
  } catch (error) {
    console.error("Error deleting order:", error);
    throw error;
  }
}

// Store Config Functions
async function getStoreConfig() {
    try {
        const result = await trickleListObjects(DB_TABLE_CONFIG, 1, true);
        if (result && result.items && result.items.length > 0) {
            return {
                id: result.items[0].objectId,
                ...result.items[0].objectData
            };
        }
        return null;
    } catch (error) {
        console.error("Error fetching store config:", error);
        return null;
    }
}

async function saveStoreConfig(data, existingId = null) {
    try {
        const payload = {
            pix_key: String(data.pix_key || ''),
            whatsapp_number: String(data.whatsapp_number || '')
        };

        if (existingId) {
            return await trickleUpdateObject(DB_TABLE_CONFIG, existingId, payload);
        } else {
            // Check if exists first to avoid duplicates if ID wasn't passed but exists
            const existing = await getStoreConfig();
            if (existing && existing.id) {
                return await trickleUpdateObject(DB_TABLE_CONFIG, existing.id, payload);
            }
            return await trickleCreateObject(DB_TABLE_CONFIG, payload);
        }
    } catch (error) {
        console.error("Error saving store config:", error);
        throw error;
    }
}

// Expose functions globally
window.fetchProducts = fetchProducts;
window.createProduct = createProduct;
window.updateProduct = updateProduct;
window.deleteProduct = deleteProduct;
window.createOrder = createOrder;
window.fetchOrders = fetchOrders;
window.updateOrder = updateOrder;
window.deleteOrder = deleteOrder;
window.getStoreConfig = getStoreConfig;
window.saveStoreConfig = saveStoreConfig;